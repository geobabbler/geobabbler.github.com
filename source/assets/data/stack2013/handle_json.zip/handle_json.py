import json
from pprint import pprint
json_data=open("C:/Workspace/Python/StackExchange/2013/gis_stack_2013_past_year.json")

data = json.load(json_data)
print "tag,count"
#print data["items"][0]["name"] + "," + str(data["items"][0]["count"])
for tag in data["items"]:
	print tag["name"] + "," + str(tag["count"])
#pprint(data)
json_data.close()
